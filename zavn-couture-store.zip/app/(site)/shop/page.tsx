import { getAllProducts } from "../../../lib/shopifyData";
import ProductCard from "../../../components/ProductCard";

export const dynamic = "force-dynamic";

export default async function ShopPage() {
  const products = await getAllProducts(48);

  return (
    <div className="container section">
      <div className="kicker">Shop</div>
      <h1 className="h1">All products</h1>
      <p className="p">Clothing + home products pulled live from Shopify.</p>

      <div style={{ height: 18 }} />

      {products.length ? (
        <div className="productGrid">
          {products.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      ) : (
        <div className="card" style={{ padding: 22 }}>
          <div className="kicker">No products yet</div>
          <h2 className="h2">Sync from Printful</h2>
          <p className="p">
            Add a product in Printful and push to Shopify. Once it exists in Shopify, it will appear here automatically.
          </p>
        </div>
      )}
    </div>
  );
}
