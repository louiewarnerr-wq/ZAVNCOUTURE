export default function ContactPage() {
  return (
    <div className="container section">
      <div className="kicker">Contact</div>
      <h1 className="h1">Get in touch</h1>
      <div className="card" style={{ padding: 22 }}>
        <p className="p">Use this email for customer support and collaborations:</p>
        <div style={{ height: 12 }} />
        <a className="btn" href="mailto:hello@zavncouture.com">hello@zavncouture.com</a>
        <div style={{ height: 18 }} />
        <p className="p">
          Want a contact form? Add a free form service (Formspree, Basin, etc.) or wire to your backend — this page is ready.
        </p>
      </div>
    </div>
  );
}
