import Image from "next/image";
import { notFound } from "next/navigation";
import { getProductByHandle } from "../../../../lib/shopifyData";
import AddToCart from "../../../../components/cart/AddToCart";
import VariantSelector from "../../../../components/cart/VariantSelector";

export const dynamic = "force-dynamic";

export default async function ProductPage({ params }: { params: { handle: string } }) {
  const product = await getProductByHandle(params.handle);
  if (!product) return notFound();

  const firstImage = product.images[0];

  return (
    <div className="container section">
      <div className="cols">
        <div className="card" style={{ overflow: "hidden" }}>
          <div style={{ position: "relative", aspectRatio: "4/5", background: "#f3f3f5" }}>
            {firstImage?.url ? (
              <Image
                src={firstImage.url}
                alt={firstImage.altText || product.title}
                fill
                sizes="(max-width: 900px) 92vw, 55vw"
                style={{ objectFit: "cover" }}
                priority
              />
            ) : null}
          </div>
          {product.images.length > 1 ? (
            <div style={{ padding: 14, display:"grid", gridTemplateColumns:"repeat(4, 1fr)", gap:10 }}>
              {product.images.slice(0, 8).map((img) => (
                <div key={img.url} style={{ position:"relative", aspectRatio:"1/1", borderRadius: 12, overflow:"hidden", border:"1px solid var(--border)" }}>
                  <Image
                    src={img.url}
                    alt={img.altText || product.title}
                    fill
                    sizes="120px"
                    style={{ objectFit: "cover" }}
                  />
                </div>
              ))}
            </div>
          ) : null}
        </div>

        <div className="card" style={{ padding: 22 }}>
          <div className="kicker">ZAVN COUTURÉ</div>
          <h1 className="h1" style={{ marginTop: 10 }}>{product.title}</h1>

          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:12, flexWrap:"wrap" }}>
            <div className="price" style={{ fontSize: 18 }}>
              {product.priceRange.minVariantPrice.amount} {product.priceRange.minVariantPrice.currencyCode}
            </div>
            <div className="badge">Made-to-order • UK shipping</div>
          </div>

          <div style={{ height: 14 }} />

          {product.description ? (
            <p className="p">{product.description}</p>
          ) : (
            <p className="p">
              Minimal luxury with street attitude. Built for daily statement and clean silhouettes.
            </p>
          )}

          <div style={{ height: 18 }} />

          <VariantSelector product={product} />

          <div style={{ height: 12 }} />

          <AddToCart product={product} />

          <div style={{ height: 18 }} />
          <div className="hr" />
          <div style={{ height: 18 }} />

          <div className="grid" style={{ gap: 12 }}>
            <div>
              <div className="kicker">Shipping</div>
              <p className="p">Printful production typically 2–5 business days. UK delivery times vary by product.</p>
            </div>
            <div>
              <div className="kicker">Returns</div>
              <p className="p">Add your final returns policy to Shopify and mirror it on this site.</p>
            </div>
            <div>
              <div className="kicker">Care</div>
              <p className="p">Wash inside out, cold. Do not iron directly on prints.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
