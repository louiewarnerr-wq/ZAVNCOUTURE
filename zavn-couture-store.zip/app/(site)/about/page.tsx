import { BRAND } from "../../_brand/brand";

export default function AboutPage() {
  return (
    <div className="container section">
      <div className="kicker">About</div>
      <h1 className="h1">{BRAND.name}</h1>
      <div className="card" style={{ padding: 22 }}>
        <p className="p">{BRAND.statement}</p>
        <div style={{ height: 14 }} />
        <p className="p">
          This store is built for a mixed brand vibe: streetwear edge, high fashion restraint, and minimalist luxury.
          Products are fulfilled via Printful through Shopify to keep quality consistent and shipping automated.
        </p>
        <div style={{ height: 14 }} />
        <div className="badge">Black • White • Grey • Gold • Silver</div>
      </div>
    </div>
  );
}
