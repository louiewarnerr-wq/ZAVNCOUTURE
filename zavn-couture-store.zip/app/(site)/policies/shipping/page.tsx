export default function ShippingPolicyPage() {
  return (
    <div className="container section">
      <div className="kicker">Policy</div>
      <h1 className="h1">Shipping</h1>
      <div className="card" style={{ padding: 22 }}>
        <p className="p">
          Orders are fulfilled via Printful. Most items are made-to-order and typically require 2–5 business days production
          before shipping. Delivery times depend on destination and product type.
        </p>
        <div style={{ height: 12 }} />
        <p className="p">
          For UK customers, you can display exact rates and delivery estimates in Shopify. This site redirects to Shopify Checkout
          where shipping options and totals are finalized.
        </p>
      </div>
    </div>
  );
}
