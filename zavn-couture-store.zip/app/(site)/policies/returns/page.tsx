export default function ReturnsPolicyPage() {
  return (
    <div className="container section">
      <div className="kicker">Policy</div>
      <h1 className="h1">Returns</h1>
      <div className="card" style={{ padding: 22 }}>
        <p className="p">
          Add your official returns policy text here. Recommended: mirror the policy you publish in Shopify for consistency.
        </p>
        <div style={{ height: 12 }} />
        <p className="p">
          For Printful-made items, returns typically apply to misprints, damaged items, or defects. For sizing exchanges and
          buyer’s remorse, set your brand policy clearly in Shopify.
        </p>
      </div>
    </div>
  );
}
