import Link from "next/link";
import Image from "next/image";
import { BRAND } from "../_brand/brand";
import { getFeaturedCollection, getProductsFromFeaturedCollection } from "../../lib/shopifyData";
import ProductCard from "../../components/ProductCard";

export default async function HomePage() {
  const collection = await getFeaturedCollection();
  const products = await getProductsFromFeaturedCollection(8);

  return (
    <div>
      <div className="container section">
        <section className="hero">
          <Image
            className="bg"
            src="https://images.unsplash.com/photo-1520975958225-6fdfc1a1e6b2?auto=format&fit=crop&w=2400&q=80"
            alt="ZAVN COUTURÉ editorial"
            fill
            priority
            sizes="100vw"
            style={{ objectFit: "cover" }}
          />
          <div className="overlay" />
          <div className="content">
            <div className="badge">
              <span style={{width:8,height:8,borderRadius:999,background:"var(--gold)",display:"inline-block"}} />
              UK-based • Made-to-order • Printful-ready
            </div>
            <h1 className="h1">{BRAND.name}</h1>
            <p className="p" style={{ color: "rgba(255,255,255,.84)", maxWidth: 620 }}>
              {BRAND.statement}
            </p>
            <div className="cta">
              <Link className="btn" href="/shop">Shop now</Link>
              {collection?.handle ? (
                <Link className="btn secondary" href={`/collections/${collection.handle}`}>Explore {collection.title}</Link>
              ) : (
                <Link className="btn secondary" href="/collections">Explore collections</Link>
              )}
            </div>
          </div>
        </section>
      </div>

      <div className="container section tight">
        <div className="cols">
          <div className="card" style={{ padding: 22 }}>
            <div className="kicker">Brand</div>
            <h2 className="h2">Street × Couture</h2>
            <p className="p">
              Minimal silhouettes, bold presence, premium feel. Built for UK drops, global shipping, and
              clean editorial storytelling.
            </p>
            <div style={{ marginTop: 14, display: "flex", gap: 10, flexWrap:"wrap" }}>
              <span className="badge">Black / White / Grey</span>
              <span className="badge">Gold & Silver accents</span>
              <span className="badge">Luxury product pages</span>
            </div>
          </div>
          <div className="card" style={{ padding: 22 }}>
            <div className="kicker">Fulfilment</div>
            <h2 className="h2">Printful-ready</h2>
            <p className="p">
              Add products in Printful → sync to Shopify → this storefront displays them instantly.
              Orders go through Shopify Checkout and fulfil automatically.
            </p>
            <div style={{ marginTop: 14, display:"flex", gap:12, flexWrap:"wrap" }}>
              <Link className="btn secondary" href="/about">About ZAVN</Link>
              <Link className="btn" href="/shop">View products</Link>
            </div>
          </div>
        </div>
      </div>

      <div className="container section">
        <div style={{ display:"flex", alignItems:"end", justifyContent:"space-between", gap:18, flexWrap:"wrap" }}>
          <div>
            <div className="kicker">Featured</div>
            <h2 className="h2">{collection?.title ?? "Latest products"}</h2>
            <p className="p">Pulled live from your Shopify store. Connect Printful to Shopify, publish products, and you're live.</p>
          </div>
          <div style={{ display:"flex", gap:10, flexWrap:"wrap" }}>
            <Link className="btn secondary" href="/collections">All collections</Link>
            <Link className="btn" href="/shop">Shop all</Link>
          </div>
        </div>

        <div style={{ height: 16 }} />

        {products.length ? (
          <div className="productGrid">
            {products.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        ) : (
          <div className="card" style={{ padding: 22 }}>
            <div className="kicker">Almost there</div>
            <h2 className="h2">Add products in Printful</h2>
            <p className="p">
              Your store is connected, but there are no products to show yet. In Printful, create a product and push it to Shopify.
              Then refresh this page.
            </p>
            <div style={{ marginTop: 14 }}>
              <Link className="btn" href="/shop">Go to shop</Link>
            </div>
          </div>
        )}
      </div>

      <div className="container section">
        <div className="card" style={{ padding: 26, background: "#0b0b0c", color: "white", borderColor: "rgba(255,255,255,.12)" }}>
          <div className="kicker" style={{ color: "rgba(255,255,255,.72)" }}>Newsletter</div>
          <h2 className="h2">Get early access to drops</h2>
          <p className="p" style={{ color: "rgba(255,255,255,.72)", maxWidth: 620 }}>
            Add your email tool later (Klaviyo / Shopify Email). This section is ready to be wired up.
          </p>
          <div style={{ marginTop: 14, display:"flex", gap:12, flexWrap:"wrap" }}>
            <a className="btn" href="mailto:hello@zavncouture.com">Contact</a>
            <Link className="btn secondary" href="/policies/shipping">Shipping</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
