import { notFound } from "next/navigation";
import { getCollectionByHandle, getProductsByCollectionHandle } from "../../../../lib/shopifyData";
import ProductCard from "../../../../components/ProductCard";

export const dynamic = "force-dynamic";

export default async function CollectionPage({ params }: { params: { handle: string } }) {
  const collection = await getCollectionByHandle(params.handle);
  if (!collection) return notFound();

  const products = await getProductsByCollectionHandle(params.handle, 48);

  return (
    <div className="container section">
      <div className="kicker">Collection</div>
      <h1 className="h1">{collection.title}</h1>
      {collection.description ? <p className="p">{collection.description}</p> : null}

      <div style={{ height: 18 }} />

      {products.length ? (
        <div className="productGrid">
          {products.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      ) : (
        <div className="card" style={{ padding: 22 }}>
          <div className="kicker">Empty collection</div>
          <h2 className="h2">Add products to this collection</h2>
          <p className="p">In Shopify Admin, add products to this collection to show them here.</p>
        </div>
      )}
    </div>
  );
}
