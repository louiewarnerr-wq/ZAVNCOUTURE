import Link from "next/link";
import { getCollections } from "../../../lib/shopifyData";

export const dynamic = "force-dynamic";

export default async function CollectionsPage() {
  const collections = await getCollections(24);

  return (
    <div className="container section">
      <div className="kicker">Collections</div>
      <h1 className="h1">Curated edits</h1>
      <p className="p">Build collections inside Shopify (e.g. New In, Essentials, Home) and they’ll appear here.</p>

      <div style={{ height: 18 }} />

      <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))" }}>
        {collections.map((c) => (
          <Link key={c.id} className="card" href={`/collections/${c.handle}`} style={{ padding: 18 }}>
            <div className="kicker">Collection</div>
            <div className="h2" style={{ marginTop: 6 }}>{c.title}</div>
            <p className="p">{c.description || "Explore the edit."}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
