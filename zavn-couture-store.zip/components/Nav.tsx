"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BRAND } from "../app/_brand/brand";
import { useCart } from "./cart/cartContext";

function IconBag() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M7 8V7a5 5 0 0 1 10 0v1" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/>
      <path d="M6 8h12l1 13H5L6 8Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"/>
    </svg>
  );
}

export default function Nav() {
  const pathname = usePathname();
  const { openCart, totalQuantity } = useCart();

  const link = (href: string, label: string) => (
    <Link href={href} aria-current={pathname === href ? "page" : undefined}>
      {label}
    </Link>
  );

  return (
    <div className="nav">
      <Link href="/" className="logo">
        <span className="mark" aria-hidden="true"><span /></span>
        <span>{BRAND.name}</span>
      </Link>

      <div className="navlinks">
        {link("/", "Home")}
        {link("/shop", "Shop")}
        {link("/collections", "Collections")}
        {link("/about", "About")}
        {link("/contact", "Contact")}
      </div>

      <div className="actions">
        <button className="iconbtn" onClick={openCart} aria-label="Open cart">
          <IconBag />
        </button>
        {totalQuantity > 0 ? (
          <span className="badge" aria-label={`${totalQuantity} items in cart`}>{totalQuantity}</span>
        ) : null}
      </div>
    </div>
  );
}
