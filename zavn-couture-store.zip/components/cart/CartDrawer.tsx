"use client";

import Image from "next/image";
import { useCart } from "./cartContext";

function XIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
    </svg>
  );
}

export default function CartDrawer() {
  const { isOpen, closeCart, lines, subtotal, inc, dec, remove, checkoutUrl } = useCart();

  if (!isOpen) return null;

  return (
    <>
      <div className="drawerBackdrop" onClick={closeCart} />
      <aside className="drawer" role="dialog" aria-label="Cart">
        <div className="drawerHeader">
          <div>
            <div className="kicker">Cart</div>
            <div style={{ fontWeight: 700, letterSpacing: ".12em", textTransform: "uppercase" }}>
              Your selection
            </div>
          </div>
          <button className="iconbtn" onClick={closeCart} aria-label="Close cart"><XIcon /></button>
        </div>

        <div className="drawerBody">
          {lines.length ? (
            lines.map((l) => (
              <div key={l.id} className="cartItem">
                <div style={{ position:"relative", width:72, height:90, borderRadius: 12, overflow:"hidden", border:"1px solid var(--border)" }}>
                  {l.imageUrl ? (
                    <Image src={l.imageUrl} alt={l.title} fill sizes="72px" style={{ objectFit:"cover" }} />
                  ) : null}
                </div>

                <div>
                  <div style={{ display:"flex", justifyContent:"space-between", gap:12 }}>
                    <div>
                      <div style={{ fontSize: 12, letterSpacing: ".08em", textTransform:"uppercase" }}>{l.title}</div>
                      {l.variantTitle && l.variantTitle !== "Default Title" ? (
                        <div className="small">{l.variantTitle}</div>
                      ) : null}
                    </div>
                    <button className="iconbtn" style={{ width:34, height:34 }} onClick={() => remove(l.id)} aria-label="Remove item">
                      <XIcon />
                    </button>
                  </div>

                  <div className="qtyRow">
                    <button className="qtyBtn" onClick={() => dec(l.id)} aria-label="Decrease quantity">−</button>
                    <div className="badge">{l.quantity}</div>
                    <button className="qtyBtn" onClick={() => inc(l.id)} aria-label="Increase quantity">+</button>
                    <div style={{ marginLeft:"auto", fontWeight:600 }}>
                      {l.lineTotal}
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="card" style={{ padding: 18 }}>
              <div className="kicker">Empty</div>
              <div className="h2" style={{ marginTop: 8 }}>Add something</div>
              <p className="p">Browse products and add to cart.</p>
            </div>
          )}
        </div>

        <div className="drawerFooter">
          <div className="line">
            <span className="small">Subtotal</span>
            <span style={{ fontWeight: 700 }}>{subtotal}</span>
          </div>
          <a className="btn" href={checkoutUrl ?? "#"} style={{ pointerEvents: checkoutUrl ? "auto" : "none", opacity: checkoutUrl ? 1 : 0.6 }}>
            Checkout
          </a>
          <button className="btn secondary" onClick={closeCart}>Continue shopping</button>
        </div>
      </aside>
    </>
  );
}
