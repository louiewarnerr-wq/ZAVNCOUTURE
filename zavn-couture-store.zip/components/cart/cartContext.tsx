"use client";

import React, { createContext, useContext, useMemo, useState } from "react";
import type { CartLine, StoreProduct, StoreVariant } from "../../lib/types";
import { createCheckout, addLinesToCheckout, updateLineQty, removeLine, getCheckout } from "../../lib/shopifyCheckout";

type CartState = {
  isOpen: boolean;
  openCart: () => void;
  closeCart: () => void;

  checkoutId: string | null;
  lines: CartLine[];
  totalQuantity: number;
  subtotal: string;

  selectedVariantIdByProduct: Record<string, string>;

  setSelectedVariant: (productId: string, variantId: string) => void;
  addToCart: (product: StoreProduct) => Promise<void>;
  inc: (lineId: string) => Promise<void>;
  dec: (lineId: string) => Promise<void>;
  remove: (lineId: string) => Promise<void>;
  checkoutUrl: string | null;
};

const Ctx = createContext<CartState | null>(null);

export function useCart() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}

function countQty(lines: CartLine[]) {
  return lines.reduce((sum, l) => sum + l.quantity, 0);
}

export default function CartProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [checkoutId, setCheckoutId] = useState<string | null>(null);
  const [lines, setLines] = useState<CartLine[]>([]);
  const [subtotal, setSubtotal] = useState("0.00");
  const [checkoutUrl, setCheckoutUrl] = useState<string | null>(null);
  const [selectedVariantIdByProduct, setSelectedVariantIdByProduct] = useState<Record<string, string>>({});

  const openCart = () => setIsOpen(true);
  const closeCart = () => setIsOpen(false);

  const syncCheckout = async (id: string) => {
    const co = await getCheckout(id);
    setLines(co.lines);
    setSubtotal(co.subtotal);
    setCheckoutUrl(co.checkoutUrl);
  };

  const ensureCheckout = async () => {
    if (checkoutId) return checkoutId;
    const co = await createCheckout();
    setCheckoutId(co.id);
    setCheckoutUrl(co.checkoutUrl);
    setLines(co.lines);
    setSubtotal(co.subtotal);
    return co.id;
  };

  const setSelectedVariant = (productId: string, variantId: string) => {
    setSelectedVariantIdByProduct((prev) => ({ ...prev, [productId]: variantId }));
  };

  const addToCart = async (product: StoreProduct) => {
    const id = await ensureCheckout();
    const selectedVariantId = selectedVariantIdByProduct[product.id] ?? product.variants[0]?.id;
    if (!selectedVariantId) return;

    await addLinesToCheckout(id, [{ variantId: selectedVariantId, quantity: 1 }]);
    await syncCheckout(id);
    openCart();
  };

  const inc = async (lineId: string) => {
    if (!checkoutId) return;
    const line = lines.find((l) => l.id === lineId);
    if (!line) return;
    await updateLineQty(checkoutId, lineId, line.quantity + 1);
    await syncCheckout(checkoutId);
  };

  const dec = async (lineId: string) => {
    if (!checkoutId) return;
    const line = lines.find((l) => l.id === lineId);
    if (!line) return;
    const next = line.quantity - 1;
    if (next <= 0) {
      await removeLine(checkoutId, lineId);
    } else {
      await updateLineQty(checkoutId, lineId, next);
    }
    await syncCheckout(checkoutId);
  };

  const remove = async (lineId: string) => {
    if (!checkoutId) return;
    await removeLine(checkoutId, lineId);
    await syncCheckout(checkoutId);
  };

  const totalQuantity = useMemo(() => countQty(lines), [lines]);

  const value: CartState = {
    isOpen,
    openCart,
    closeCart,
    checkoutId,
    lines,
    totalQuantity,
    subtotal,
    selectedVariantIdByProduct,
    setSelectedVariant,
    addToCart,
    inc,
    dec,
    remove,
    checkoutUrl
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
