"use client";

import CartProvider from "./cartContext";
import CartDrawer from "./CartDrawer";

export default function Provider({ children }: { children: React.ReactNode }) {
  return (
    <CartProvider>
      {children}
      <CartDrawer />
    </CartProvider>
  );
}
