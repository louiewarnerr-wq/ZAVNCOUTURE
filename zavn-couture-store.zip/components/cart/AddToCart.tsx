"use client";

import type { StoreProduct } from "../../lib/types";
import { useCart } from "./cartContext";

export default function AddToCart({ product }: { product: StoreProduct }) {
  const { addToCart, selectedVariantIdByProduct } = useCart();
  const selectedVariantId = selectedVariantIdByProduct[product.id] ?? product.variants[0]?.id;
  const selectedVariant = product.variants.find((v) => v.id === selectedVariantId) ?? product.variants[0];

  const disabled = !selectedVariant?.availableForSale;

  return (
    <button className="btn" onClick={() => addToCart(product)} disabled={disabled} style={{ width:"100%" }}>
      {disabled ? "Sold out" : "Add to cart"}
    </button>
  );
}
