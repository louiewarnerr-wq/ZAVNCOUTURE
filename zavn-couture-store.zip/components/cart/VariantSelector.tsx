"use client";

import { useMemo } from "react";
import type { StoreProduct } from "../../lib/types";
import { useCart } from "./cartContext";

export default function VariantSelector({ product }: { product: StoreProduct }) {
  const { selectedVariantIdByProduct, setSelectedVariant } = useCart();

  const selected = selectedVariantIdByProduct[product.id] ?? product.variants[0]?.id ?? "";
  const hasMultiple = product.variants.length > 1;

  const options = useMemo(() => {
    return product.variants.map((v) => ({
      id: v.id,
      title: v.title,
      available: v.availableForSale
    }));
  }, [product.variants]);

  if (!hasMultiple) return null;

  return (
    <div>
      <div className="kicker">Variant</div>
      <div style={{ height: 8 }} />
      <select
        value={selected}
        onChange={(e) => setSelectedVariant(product.id, e.target.value)}
        style={{
          width: "100%",
          padding: "12px 14px",
          borderRadius: 14,
          border: "1px solid var(--border)",
          background: "#fff",
          fontSize: 14
        }}
        aria-label="Select variant"
      >
        {options.map((o) => (
          <option key={o.id} value={o.id} disabled={!o.available}>
            {o.title}{o.available ? "" : " (Sold out)"}
          </option>
        ))}
      </select>
    </div>
  );
}
