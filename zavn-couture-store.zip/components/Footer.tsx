import Link from "next/link";
import { BRAND } from "../app/_brand/brand";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footerGrid">
        <div>
          <div className="logo" style={{ marginBottom: 10 }}>
            <span className="mark" aria-hidden="true"><span /></span>
            <span>{BRAND.name}</span>
          </div>
          <p className="p">{BRAND.tagline}</p>
          <div style={{ height: 10 }} />
          <div className="badge">UK • Printful fulfilment • Shopify checkout</div>
        </div>

        <div>
          <h4>Shop</h4>
          <Link href="/shop">All products</Link>
          <Link href="/collections">Collections</Link>
          <Link href="/policies/shipping">Shipping</Link>
          <Link href="/policies/returns">Returns</Link>
        </div>

        <div>
          <h4>Company</h4>
          <Link href="/about">About</Link>
          <Link href="/contact">Contact</Link>
        </div>

        <div>
          <h4>Social</h4>
          <a href={BRAND.socials.instagram} target="_blank" rel="noreferrer">Instagram</a>
          <a href={BRAND.socials.tiktok} target="_blank" rel="noreferrer">TikTok</a>
          <a href={BRAND.socials.pinterest} target="_blank" rel="noreferrer">Pinterest</a>
        </div>
      </div>

      <div style={{ height: 18 }} />
      <div className="hr" />
      <div style={{ height: 14 }} />
      <div style={{ display:"flex", justifyContent:"space-between", gap:12, flexWrap:"wrap" }}>
        <span className="small">© {new Date().getFullYear()} {BRAND.name}. All rights reserved.</span>
        <span className="small">Built for Vercel • Next.js • Shopify</span>
      </div>
    </footer>
  );
}
