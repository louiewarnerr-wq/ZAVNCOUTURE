import Link from "next/link";
import Image from "next/image";
import type { StoreProduct } from "../lib/types";

export default function ProductCard({ product }: { product: StoreProduct }) {
  const img = product.images[0];

  return (
    <Link className="pcard" href={`/product/${product.handle}`}>
      <div className="img">
        {img?.url ? (
          <Image
            src={img.url}
            alt={img.altText || product.title}
            fill
            sizes="(max-width: 780px) 45vw, 25vw"
            style={{ objectFit: "cover" }}
          />
        ) : null}
      </div>
      <div className="info">
        <div className="title">{product.title}</div>
        <div style={{ display:"flex", alignItems:"baseline", justifyContent:"space-between", gap:10 }}>
          <span className="price">
            {product.priceRange.minVariantPrice.amount} {product.priceRange.minVariantPrice.currencyCode}
          </span>
          <span className="small">{product.vendor || "ZAVN COUTURÉ"}</span>
        </div>
      </div>
    </Link>
  );
}
